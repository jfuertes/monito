<?php

/**
 *  Author: Eisson Alipio
 *  Date: 30 Noviembre 2015 - 12:08 am
 *  Last update: 20 Agosto 2015
 *  function: Database configuration
 */

# STMP HOST
#define('HOST_MAIL', 'ip_here');

/*
define('CLAVE', 'minsa');
define('DB_USERNAME', 'esdeporv_entel');
define('DB_PASSWORD', 'qv112ifV3E');
define('DB_HOST', 'localhost');
define('DB_NAME', 'esdeporv_vacuna');
*/

# MySQL Credentials :
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_NAME', 'miprofe');



?>